### IMPORTANT
- If you are running this in live-server or some sort of server environment there is no need to compile sass, you can delete the CSS files